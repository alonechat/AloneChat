from .kick import PluginImpl as KickPlugin

__all__ = ['KickPlugin']