from .aes import PluginImpl as AESEncryptor

__all__ = ['AESEncryptor']